//
//  ViewController.swift
//  iTunesPicker
//
//  Created by Ingo Ngoyama on 2/20/21.
//

import UIKit

class SearchVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

